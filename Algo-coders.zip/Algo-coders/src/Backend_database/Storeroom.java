package Backend_database;

public class Storeroom {


    public void mainStore() {


    }
}