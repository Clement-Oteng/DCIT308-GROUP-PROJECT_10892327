package frames;

import javax.swing.*;
import java.awt.*;


public class viewBill_p extends JPanel {


    viewBill_p(){
        setBackground(Color.RED);
    }
}
